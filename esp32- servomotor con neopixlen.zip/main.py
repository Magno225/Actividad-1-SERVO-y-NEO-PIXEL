from machine import Pin, PWM
from neopixel import NeoPixel
import time

# Configuración del servo (PWM en el pin 13)
servo = PWM(Pin(13), freq=50)

# Configuración del NeoPixel Ring (pin 26, con 16 LEDs)
num_leds = 16
np = NeoPixel(Pin(26), num_leds)

# Función para mover el servo a un ángulo específico
def set_servo_angle(angle):
    duty = int((angle / 180 * 102) + 26)  # Mapear 0-180 grados a duty cycle (26-128 aprox.)
    servo.duty(duty)

# Función para iluminar el LED blanco en la posición del servo, con fondo de color
def set_led_position(angle, bg_color):
    led_index = int((angle / 180) * (num_leds - 1))  # Mapear 0-180 grados a índices 0-15
    
    # Pintar todos los LEDs con el color de fondo
    for i in range(num_leds):
        np[i] = bg_color  # Rojo o verde

    # Colocar el LED blanco en la posición correspondiente al servo
    np[led_index] = (255, 255, 255)  
    np.write()

# Bucle infinito para movimiento continuo de lado a lado
while True:
    # Recorrido hacia la derecha (0° a 180°) con fondo rojo
    for angle in range(0, 181, 5):  
        set_servo_angle(angle)
        set_led_position(angle, (255, 0, 0))  # Fondo rojo
        time.sleep(0.05)

    # Recorrido hacia la izquierda (180° a 0°) con fondo verde
    for angle in range(180, -1, -5):  
        set_servo_angle(angle)
        set_led_position(angle, (0, 255, 0))  # Fondo verde
        time.sleep(0.05)